/* Theme toggle */
const themeToggle = document.getElementById('theme-toggle');
if (themeToggle){
  const saved = localStorage.getItem('lfs-theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  themeToggle.textContent = saved === 'dark' ? '☀️ Light' : '🌙 Dark';
  themeToggle.addEventListener('click', ()=>{
    const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', current);
    localStorage.setItem('lfs-theme', current);
    themeToggle.textContent = current === 'dark' ? '☀️ Light' : '🌙 Dark';
  });
}

/* Carousel */
class Carousel {
  constructor(id, interval=3500){
    this.container = document.getElementById(id);
    if (!this.container) return;
    this.slides = Array.from(this.container.querySelectorAll('.slide'));
    this.index = 0;
    this.show(this.index);
    this.timer = setInterval(()=>this.next(), interval);
    this.container.addEventListener('mouseenter', ()=>clearInterval(this.timer));
    this.container.addEventListener('mouseleave', ()=>this.timer = setInterval(()=>this.next(), interval));
    const prev = this.container.querySelector('.prev');
    const next = this.container.querySelector('.next');
    if (prev) prev.addEventListener('click', ()=>this.prev());
    if (next) next.addEventListener('click', ()=>this.next());
  }
  show(i){ this.slides.forEach((s,idx)=> s.style.display = idx===i ? 'block' : 'none'); }
  next(){ this.index = (this.index+1)%this.slides.length; this.show(this.index); }
  prev(){ this.index = (this.index-1+this.slides.length)%this.slides.length; this.show(this.index); }
}
document.addEventListener('DOMContentLoaded', ()=> new Carousel('hero-carousel', 3000));

/* Contact form validation */
const contactForm = document.getElementById('contact-form');
if (contactForm){
  contactForm.addEventListener('submit', (e)=>{
    e.preventDefault();
    const name = contactForm.querySelector('[name="name"]').value.trim();
    const email = contactForm.querySelector('[name="email"]').value.trim();
    const message = contactForm.querySelector('[name="message"]').value.trim();
    if (!name || !email || !message){ alert('Please fill name, email and message.'); return; }
    if (!/^\S+@\S+\.\S+$/.test(email)){ alert('Please enter a valid email.'); return; }
    alert('Thanks '+name+'! Your enquiry has been received.');
    contactForm.reset();
  });
}

/* Menu search filter */
const menuSearch = document.getElementById('menu-search');
if (menuSearch){
  menuSearch.addEventListener('input', (ev)=>{
    const q = ev.target.value.toLowerCase();
    document.querySelectorAll('.menu-item').forEach(item=>{
      const title = item.querySelector('.menu-title').textContent.toLowerCase();
      const desc = item.querySelector('.menu-desc').textContent.toLowerCase();
      item.style.display = title.includes(q) || desc.includes(q) ? 'block' : 'none';
    });
  });
}
